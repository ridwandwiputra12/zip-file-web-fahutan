<?php
include('mahasiswa/db.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <meta name="description" content="" />
   <meta name="author" content="" />
   <title>LABORATORIUM FAHUTAN</title>
   <link rel="stylesheet" href="bootstrap/bootstrap-5.0.2-dist/css/bootstrap.min.css">
   <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
   <link href="css/styles.css" rel="stylesheet" />
   <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
   <style>
      #grey {
         color: #444444;
      }

      .bgc {
         background-color: #FBFBFB;
      }

      span {
         color: red;
      }

      .bx-shadow {
         box-sizing: border-box;
         box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;
         margin: auto;
      }

      .alert-atas {
         position: absolute;
         top: 0px;
         right: 0;
      }
   </style>
</head>

<body class="sb-nav-fixed bgc">
   <main>
      <div class="container-fluid px-3">
         <ol class="breadcrumb mt-2">
            <li class="breadcrumb-item active">
               <h5>Registrasi Akun</h5>
            </li>
         </ol>
         <div class="card bx-shadow col-md-8">
            <div class="card-header">
               <h5 class="mb-4 mt-4">Masukkan Data</h5>
            </div>
            <div class="card-body">
               <form class="row g-3" method="POST" enctype="multipart/form-data">
               <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>NIM</b></label>
                     <input type="text" class="form-control" name="nim" />
                  </div>   
               <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Nama Mahasiswa</b></label>
                     <input type="text" class="form-control" name="nama" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Username</b><span>*</span></label>
                     <input type="text" class="form-control" name="user_mahasiswa" / required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Password </b><i>(terdiri huruf atau angka maksimal 20 karakter)</i></label>
                     <input type="text" class="form-control" name="pass_mahasiswa" / placeholder="contoh: paudtanjungselor01" required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Jenis Kelamin</b></label>
                     <input type="text" class="form-control" name="jenis_kelamin" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Kelas</b></label>
                     <input type="text" class="form-control" name="kelas" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Alamat</b></label>
                     <input type="text" class="form-control" name="alamat" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Fakultas</b></label>
                     <input type="text" class="form-control" name="fakultas" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Prodi</b></label>
                     <input type="text" class="form-control" name="prodi" />
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label-md" id="grey"><b>Telepon</b></label>
                     <input type="text" class="form-control" name="telp" />
                  </div>
                  <p><b>Note:</b> Harap diingat atau disimpan nomor NPSN dan Password untuk digunakan login</p>
                  <div class="col-md-12">
                     <button type="submit" name="submit" class="btn btn-primary" style="float: right;">
                        Submit
                     </button>
                  </div>
               </form>

               <?php
               if (isset($_POST['submit'])) {
                  $nim = $_POST['nim'];
                  $nama = $_POST['nama'];
                  $user_mahasiswa = $_POST['user_mahasiswa'];
                  $pass_mahasiswa = $_POST['pass_mahasiswa'];
                  $jenis_kelamin = $_POST['jenis_kelamin'];
                  $kelas = $_POST['kelas'];
                  $alamat = $_POST['alamat'];
                  $fakultas = $_POST['fakultas'];
                  $prodi = $_POST['prodi'];
                  $telp = $_POST['telp'];

                  if (strlen($pass_mahasiswa) >= 6 && strlen($pass_mahasiswa) <= 20) {
                     $query = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE nim='$nim'");
                     if (mysqli_num_rows($query) == 0) {
                        $add = mysqli_query($conn, "INSERT INTO mahasiswa VALUES(null,
                          '" . $nim . "', 
                          '" . $nama . "',
                          '" . $user_mahasiswa . "',
                          '" . $pass_mahasiswa . "',
                          '" . $jenis_kelamin . "',
                          '" . $kelas . "',
                          '" . $alamat . "',
                          '" . $fakultas . "',
                          '" . $prodi . "',
                          '" . $telp . "')");
                        if ($add) {
                           echo '<script>alert("data berhasil di tambahkan")</script>';
               ?>
                           <div class="alert alert-success alert-dismissible alert-atas"><img src="icons/check2-square.svg" alt=""> Pendaftaran berhasil, gunakan <br>NIM: <b><?php echo $nim ?></b> <br>Password: <b><?php echo $pass_mahasiswa ?></b> <br>untuk login <a href="index.php" target="_blank" class="alert-link"> Klik disini</a>
                              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
                           </div>
                        <?php
                        } else {
                           echo 'pendaftaran gagal ' . mysqli_error($conn);
                        }
                     } else {
                        ?>
                        <div class="alert alert-danger alert-dismissible alert-atas"><img src="icons/exclamation-circle-fill.svg" style="margin-bottom: 4px;"> <span class="alert-link">Pendaftaran gagal,</span> NIM <b><?php echo $nim ?></b> telah terdaftar. Tidak dapat mendaftar dua kali <br> Silahkan laporkan kepada Admin
                           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
                        </div>
                     <?php
                     }
                  } else {
                     ?>
                     <div class="alert alert-danger alert-dismissible alert-atas"><img src="icons/exclamation-circle-fill.svg" style="margin-bottom: 4px;"> <span class="alert-link">Pendaftaran gagal,</span> Minimal password 6 karakter & Maksimal password 20 karakter
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
                     </div>
               <?php }
               } ?>

            </div>
         </div>
      </div>
   </main>
   <footer class="py-4 bg-light mt-auto">
      <div class="container-fluid px-4">
         <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">
               Copyright &copy; Sistem Aplikasi Pelaporan Pendidikan
               Anak Usia Dini
            </div>
            <div>
               <a href="#">Privacy Policy</a>
               &middot;
               <a href="#">Terms &amp; Conditions</a>
            </div>
         </div>
      </div>
   </footer>
   </div>
   </div>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
   <script src="js/scripts.js"></script>
   <script src="assets/demo/chart-area-demo.js"></script>
   <script src="assets/demo/chart-bar-demo.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
   <script src="js/datatables-simple-demo.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
</body>

</html>